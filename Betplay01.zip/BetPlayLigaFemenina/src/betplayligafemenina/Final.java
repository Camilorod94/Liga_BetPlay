/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina;

/**
 *
 * @author USUARIO
 */

class Final { // representa un partido final entre dos equipos en el torneo de la Liga Femenina de BetPlay.
    private Equipo equipoLocal;// El equipo local en la final
    private Equipo equipoVisitante;// El equipo visitante en la final
    private int golesLocal;// Los goles del equipo local
    private int golesVisitante; // Los goles del equipo visitante
    private String estadio;// El estadio donde se jugó la final
    private String ganador;// El equipo ganador de la final

    
    // Constructor para crear una instancia de "Final" con los detalles de la final
    public Final(Equipo equipoLocal, Equipo equipoVisitante, int golesLocal, int golesVisitante, String estadio, String ganador) {
        this.equipoLocal = equipoLocal; // Inicializar el equipo local con el valor proporcionado
        this.equipoVisitante = equipoVisitante;// Inicializar el equipo visitante con el valor proporcionado
        this.golesLocal = golesLocal; // Inicializar los goles del equipo local con el valor proporcionado
        this.golesVisitante = golesVisitante; // Inicializar los goles del equipo visitante con el valor proporcionado
        this.estadio = estadio; // Inicializar el estadio con el valor proporcionado
        this.ganador = ganador; // Inicializar el ganador con el valor proporcionado
    }

    // Método para obtener información detallada sobre la final
    public String obtenerInfo() {
        return "Partido:\n" +
               equipoLocal.getNombre() + " " + golesLocal + " - " +
               golesVisitante + " " + equipoVisitante.getNombre() + "\n" +
               "Estadio: " + estadio + "\n" +
               "Ganador: " + ganador + "\n";
    }
}
 
//Esta clase permite encapsular la información sobre una final específica, 
//incluidos los detalles sobre los equipos participantes, los goles marcados y el ganador. 
//Se utiliza en el programa para representar las finales de cada año en el torneo y mostrar detalles sobre los partidos finales.
