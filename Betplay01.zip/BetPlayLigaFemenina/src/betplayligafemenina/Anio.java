/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina;

/**
 *
 * @author Camilo De Los Rios.
 */

//SUPER CLASE

// Clase abstracta para representar un año específico en el torneo
abstract class Anio {
    // Atributos privados para almacenar los detalles del año
    private int anio; // El año del torneo
    private Equipo equipoCampeon; // El equipo campeón del torneo en ese año
    private Equipo equipoSubcampeon; // El equipo subcampeón del torneo en ese año
    private Final finalPartidoIda; // Los detalles del partido de ida de la final en ese año
    private Final finalPartidoVuelta; // Los detalles del partido de vuelta de la final en ese año
    private Jugadora goleadora; // La jugadora goleadora del torneo en ese año

    // Constructor para crear un objeto de tipo Anio con los detalles proporcionados
    public Anio(int anio, Equipo equipoCampeon, Equipo equipoSubcampeon, Final finalPartidoIda, Final finalPartidoVuelta, Jugadora goleadora) {
        this.anio = anio; // Inicializar el año con el valor proporcionado
        this.equipoCampeon = equipoCampeon; // Inicializar el equipo campeón con el valor proporcionado
        this.equipoSubcampeon = equipoSubcampeon; // Inicializar el equipo subcampeón con el valor proporcionado
        this.finalPartidoIda = finalPartidoIda; // Inicializar los detalles del partido de ida con el valor proporcionado
        this.finalPartidoVuelta = finalPartidoVuelta; // Inicializar los detalles del partido de vuelta con el valor proporcionado
        this.goleadora = goleadora; // Inicializar la jugadora goleadora con el valor proporcionado
    }

    // Método abstracto que debe ser implementado en las subclases para obtener información detallada sobre el año
    public abstract String obtenerInfoAnio();

    // Métodos para acceder a los detalles del año
    public int getAnio() {
        return anio;
    }

    public Equipo getEquipoCampeon() {
        return equipoCampeon;
    }

    public Equipo getEquipoSubcampeon() {
        return equipoSubcampeon;
    }

    public Final getFinalPartidoIda() {
        return finalPartidoIda;
    }

    public Final getFinalPartidoVuelta() {
        return finalPartidoVuelta;
    }

    public Jugadora getGoleadora() {
        return goleadora;
    }

    // Sobrescribir el método toString para obtener información del año al convertir el objeto a cadena de texto
    @Override
    public String toString() {
        return obtenerInfoAnio();
    }
}

//La clase "Anio" proporciona la estructura base y los métodos necesarios para representar y acceder a los detalles de un año específico en el torneo de la 
//Liga Femenina de BetPlay. Las subclases que representan años específicos deben implementar el método obtenerInfoAnio() para ofrecer información detallada 
//sobre ese año en particular.
