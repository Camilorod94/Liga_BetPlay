/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina;

/**
 *
 * @author Camilo De Los Rios.
 */
class Jugadora {
    private String nombre; // El nombre de la jugadora
    private int goles; // La cantidad de goles que ha marcado la jugadora

    public Jugadora(String nombre, int goles) { // Constructor para crear una jugadora con su nombre y la cantidad de goles
        this.nombre = nombre; // Inicializar el nombre con el valor proporcionado
        this.goles = goles; // Inicializar la cantidad de goles con el valor proporcionado
    }

      public String getNombre() {   // Método para obtener el nombre de la jugadora
        return nombre;
    }

        public int getGoles() { // Método para obtener la cantidad de goles que ha marcado la jugadora
        return goles;
    }
}
