/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina;

/**
 *
 * @author Camilo De Los Rios.
 */


// Subclase de Anio que representa el año 2020 en el torneo de la Liga Femenina de BetPlay
class Anio2020 extends Anio {
    
    // Constructor de la subclase Anio2020
    public Anio2020() {
        // Llamada al constructor de la clase base (Anio) para crear un objeto Anio2020 con detalles específicos del año 2020
        super(
            2020, // Año
            new Equipo("Santa Fe"), // Equipo campeón
            new Equipo("América de Cali"), // Equipo subcampeón
            new Final(
                new Equipo("América de Cali"), // Equipo local
                new Equipo("Santa Fe"), // Equipo visitante
                1, 2, // Resultado ida
                "Estadio Pascual Guerrero, Cali", // Lugar ida
                "América de Cali" // Equipo ganador ida
            ),
            new Final(
                new Equipo("Santa Fe"), // Equipo local
                new Equipo("América de Cali"), // Equipo visitante
                2, 0, // Resultado vuelta
                "Estadio El Campín, Bogotá", // Lugar vuelta
                "Santa Fe" // Equipo ganador vuelta
            ),
            new Jugadora("Ysaura Viso", 13) // Goleadora del año 2020
        );
    }

    // Implementación del método abstracto obtenerInfoAnio() para mostrar información detallada del año 2020
    @Override
    public String obtenerInfoAnio() {
        // Crear una cadena con la información detallada del año 2020
        return "Año 2020:\n" +
            "Campeón: " + getEquipoCampeon().getNombre() + "\n" +// Obtener información detallada del campeón
            "Subcampeón: " + getEquipoSubcampeon().getNombre() + "\n" + // Obtener información detallada del subcampeón
            "Goleadora: " + getGoleadora().getNombre() + " (" + getGoleadora().getGoles() + " goles)\n" +// Obtener información detallada del nombre y goles de la goleadora
            "Detalles del partido ida:\n" +
            getFinalPartidoIda().obtenerInfo() + "\n" + // Obtener información detallada del partido de ida
            "Detalles del partido vuelta:\n" +
            getFinalPartidoVuelta().obtenerInfo(); // Obtener información detallada del partido de vuelta
    }
}

//La subclase Anio2020 proporciona una implementación específica para representar el año 2020 en el torneo, 
//mostrando información detallada sobre ese año, incluyendo los equipos, 
//los resultados de los partidos de ida y vuelta de la final y la goleadora.
