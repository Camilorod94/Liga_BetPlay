/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina;

/**
 *
 * @author Camilo De Los Rios.
 */
class Equipo { // Se crea clase equipo que representa cada equipo que participa.
    private String nombre; // Atributo nombre que identifica al equipo. 

    public Equipo(String nombre) { // Constructor para crear un equipo con su nombre
        this.nombre = nombre; // Inicializar el nombre con el valor proporcionado
    }

    public String getNombre() { // Método para obtener el nombre del equipo
        return nombre;
    }
}

// La clase "Equipo" permite encapsular la información relevante de un equipo, como su nombre, para ser utilizada en otras partes del programa, como en la representación de las finales.
