/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package betplayligafemenina;

import java.util.Scanner;
/**
 *
 * @author Camilo De Los Rios.
 */
public class BetPlayLigaFemenina { // EL main imprime el menú principañ.
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Se crea variable para scanner y que el usuario ingrece opción por teclado. 
        int opcion; //Opción se declara como Int, que sea leido un número. Switch

        do {
            // Mmenú para que el usuario seleccione el año
            System.out.println("***Bienvenido al histórico de BetPlay femenino***\n");
            System.out.println("Seleccione el año de su interés:");
            System.out.println("1. 2023");
            System.out.println("2. 2022");
            System.out.println("3. 2021");
            System.out.println("4. 2020");
            System.out.println("5. Salir");
            opcion = scanner.nextInt();

            System.out.println();

            // Se abre el menú en el Switch
            switch (opcion) {
                case 1:
                    mostrarInfoAnio(new Anio2023()); // cada case llama un método. Para este caso el método "mostrar info" declarado en cada Anio. 
                    break;
                case 2:
                    mostrarInfoAnio(new Anio2022());
                    break;
                case 3:
                    mostrarInfoAnio(new Anio2021());
                    break;
                case 4:
                    mostrarInfoAnio(new Anio2020());
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida."); // Si no eligen una opción del 1 al 5 del menú, dirá que la opción no es valida y repetirá el menú. 
                    break;
            }

            System.out.println(); //Genera un espacio extra para que quede visiblemente mejor. 

        } while (opcion != 5); // Se cierra el ciclo al seleccionar 5. 
    }
 


    public static void mostrarInfoAnio(Anio anio) { // declara el método para ser llamado. 
        System.out.println(anio.obtenerInfoAnio());
    }
}
