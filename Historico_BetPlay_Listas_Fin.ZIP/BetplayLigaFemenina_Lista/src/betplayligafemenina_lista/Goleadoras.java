/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_lista;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.List;

public class Goleadoras {
    public static void main(String[] args) {
        // Crear una "Lista Genérica" para almacenar goleadoras de los equipos 
        
         System.out.println("");//Se deja espacio para separar del título
        System.out.println("***Estas son las goleadoras destacadas***");
        List<String> Goleadoras = new ArrayList<>();
        
        System.out.println("");//Se deja espacio para separar del título
        Goleadoras.add("Catalina Usme ");
        Goleadoras.add("Liana Salazar ");
        Goleadoras.add("María Camila Reyes");
        Goleadoras.add("Leidy Cobos");
        Goleadoras.add("Ana González");

        // Mostrar los nombres de todas la goleadoras

        for (String Goleadora : Goleadoras) {
            System.out.println(Goleadora);
        }
    }
}
