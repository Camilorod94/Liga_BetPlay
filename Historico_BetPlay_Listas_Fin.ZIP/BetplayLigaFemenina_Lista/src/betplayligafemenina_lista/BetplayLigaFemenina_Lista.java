/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package betplayligafemenina_lista;


import java.util.Scanner;

/**
 * Esta clase representa el menú principal de la aplicación de la Liga BetPlay Femenina.
 * Permite al usuario seleccionar diversas opciones para obtener información sobre el torneo.
 * También contiene un bucle que permite al usuario interactuar con la aplicación hasta que elija salir.
 * 
 * @author Kmilo
 */

public class BetplayLigaFemenina_Lista {

    public static void main(String[] args) {
        System.out.println("BIENVENIDO A SU HISTORICO BETPLAYFEM2023\n");
        
        System.out.println("Para acceder al historico, ingrese su usuario y contraseña");
        System.out.println("");
        System.out.println("Usuario: ciclo3 - contraseña: proyecto");
        System.out.println("");
        
        Scanner scr = new Scanner(System.in); // Creamos un Scanner para obtener entrada del usuario
        int opcion; // Variable para almacenar la opción seleccionada por el usuario
        String usuario;
        String contrasena;
        
        

        // Solicitar al usuario que ingrese el nombre de usuario y contraseña
        do {
            System.out.print("Usuario: ");
            usuario = scr.next();
            System.out.print("Contraseña: ");
            contrasena = scr.next();
            
            // Verificar si el usuario y la contraseña son correctos
            if (!usuario.equals("ciclo3") || !contrasena.equals("proyecto")) {
                System.out.println("Error: Usuario o contraseña incorrectos. Intente nuevamente.");
            }
        } while (!usuario.equals("ciclo3") || !contrasena.equals("proyecto"));

        // Una vez que el usuario y la contraseña son correctos, mostrar el menú principal
        do {
            // Mostramos el menú al usuario
            System.out.println("\n ***BIENVENIDO A HISTOBET-FEM*** \n");
            System.out.println("Seleccione la opción que desea consultar:");
            System.out.println("1. Subcampeones de los últimos 4 años ");
            System.out.println("2. Total de Equipos que participaron ");
            System.out.println("3. Datos de cada Año");
            System.out.println("4. Goleadoras");
            System.out.println("5. Equipos finalistas");
            System.out.println("6. Goles total de la liga");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scr.nextInt(); // Obtenemos la opción elegida por el usuario

            switch (opcion) {
                case 1:
                    // Mostramos datos de la Liga BetPlayFem2023
                    System.out.println("SUBCAMPEONES DE LOS ULTIMOS 4 AÑOS :");
                    SUBCAMPEONES.main(args);
                    break;
                case 2:
                    // Mostramos equipos que clasifican para la final
                    System.out.println("\n\nEQUIPOS QUE HAN JUGADO EN TODAS LAS TEMPORADAS");
                    TotalEquipos.main(args);
                    break;
                case 3:
                    // Mostramos datos sobre el equipo
                    System.out.println("\n\nDATOS DE LOS ULTIMOS 4 AÑOS:");
                    DetallesAnios.main(args);
                    break;
                case 4:
                    // Mostramos las goleadoras destacadas
                    System.out.println("\n\nGOLEADORAS DESTACADAS:");
                    Goleadoras.main(args);
                    break;
                    
                case 5:
                    // Mostramos las posiciones de los equipos finalistas 
                    System.out.println("\n\nPOSICION EQUIPOS FINALISTAS:");
                    Posicionfinalistas.main(args);
                    break;
                    
                case 6:
                    // Mostramos el total de goles anotados durante la liga
                    System.out.println("\n\nTOTAL GOLES DURANTE LA LIGA:");
                    TotalGolesLiga.main(args);
                    break;
                    
                case 7:
                    // Salimos del programa
                    System.out.println("\n¡¡¡Gracias por usar HISTOBET-FEM!!!\ncristian.de.los.rios@pi.edu.co");
                    break;
                    
                default:
                    // Si la opción no es válida, mostramos un mensaje de error
                    System.out.println("Opcion no valida. Por favor, seleccione una opcion valida.");
                    break;
            }

        } while (opcion != 7); // Continuamos el bucle mientras la opción no sea 7 (Salir)
    }
}
