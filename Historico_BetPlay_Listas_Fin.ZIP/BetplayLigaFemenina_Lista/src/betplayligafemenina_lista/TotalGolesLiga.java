/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_lista;

/**
 *
 * @author nicol
 */
import java.util.Stack;

public class TotalGolesLiga {
    public static void main(String[] args) {
        // Crear una pila llamada "TotalGolesLiga" para simular el total de goles anotados por los equipos
        
        System.out.println("");//Se deja espacio para separar del título
        System.out.println("***Aquí verá el total de goles del último torneo***");
        System.out.println("");//Se deja espacio para separar del título
        
        Stack<Integer> TotalGoles = new Stack<>();
        TotalGoles.push(10); // goles del equipo America De cali
        TotalGoles.push(25); // goles del equipo SantaFe
        TotalGoles.push(10); // goles del equipo Atletico Nacional
        TotalGoles.push(29); // goles del equipo Pereira
        TotalGoles.push(17); // goles del equipo Deportivo Cali
        TotalGoles.push(7); // goles del equipo Independiente Medellin
        TotalGoles.push(3); // goles del equipo Equidad
        TotalGoles.push(10); // goles del equipo Millonarios
        TotalGoles.push(12); // goles del equipo Llaneros Femenina
        TotalGoles.push(12); // goles del equipo Junior
        TotalGoles.push(12); // goles del equipo Boyacá Chicó Femenina	
        TotalGoles.push(10); // goles del equipo Huila
        TotalGoles.push(10); // goles del equipo RST
        TotalGoles.push(13); // goles del equipo Pasto
        TotalGoles.push(12); // goles del equipo Bucaramanga
        TotalGoles.push(6); // goles del equipo Tolima

        // Calcular los goles anotados en este año 2023
        int goles = 0;
        while (!TotalGoles.isEmpty()) {
            goles += TotalGoles.pop();
        }

        // Mostrar los Goles totales anotados en la LigaBetPlayFem 2023
        System.out.println("El total de goles anotados por los equipos: " + goles + " goles");
    }
}
