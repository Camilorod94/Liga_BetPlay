/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_lista;

/**
 *
 * @author nicol
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

class Equipofinalista {
    String nombre;
    String posicion;

    public Equipofinalista(String nombre, String posicion) {
        this.nombre = nombre;
        this.posicion = posicion;
    }
}
// método de iteracción
public class Posicionfinalistas {
    public static void main(String[] args) {
        // Crear una lista con los equipos finalistas de fútbol
        
        System.out.println("");//Se deja espacio para separar del título
        System.out.println("***Aquí verá al equiopo que ocupó el tercer puesto en el 2023***");
        System.out.println("");//Se deja espacio para separar del título
   
        List<Equipofinalista> Equipo = new ArrayList<>();
        Equipo.add(new Equipofinalista("America De Cali", "Tercer Lugar"));
        Equipo.add(new Equipofinalista("Millonarios", "Segundo Lugar"));
        Equipo.add(new Equipofinalista("SantaFe", "Primer Lugar"));

        // Método para buscar un equipo de fútbol por su posición
        String posicionEquipoBuscado = "Tercer Lugar";
        Optional<Equipofinalista> Equipobuscado = buscarEquipoPorPosicion(Equipo, posicionEquipoBuscado);

        // Mostrar información del equipo de fútbol buscado
        if (Equipobuscado.isPresent()) {
            Equipofinalista EquipoEncontrada = Equipobuscado.get();
            System.out.println(EquipoEncontrada.nombre + " quedó en " + EquipoEncontrada.posicion);
        } else {
            System.out.println("No se encontró ningun equipo en la posición " + posicionEquipoBuscado);
        }
    }

    // Método para buscar un equipo de fútbol por su posición
    private static Optional<Equipofinalista> buscarEquipoPorPosicion(List<Equipofinalista> listaEquipos, String posicion) {
        return listaEquipos.stream()
                .filter(Equipo -> Equipo.posicion.equals(posicion))
                .findFirst();
    }
}
