/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_lista;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta clase muestra información sobre los subcampeones de los últimos 4 años de la Liga BetPlay Femenina.
 * Cada subcampeón se almacena en una lista y se muestra su posición ordinal y nombre.
 * @author Kmilo
 */
public class SUBCAMPEONES {
    public static void main(String[] args) {
    
        System.out.println("");//Se deja espacio para separar del título
        System.out.println("***Estos son los subcampeones de los últimos 4 años***");
        // Crear una "Lista Posición Ordinal" para los subcampeones de los últimos 4 años
        List<String> Subcampeon = new ArrayList<>();
        Subcampeon.add("America De Cali - 2023");
        Subcampeon.add("Deportaivo Cali - 2022");
        Subcampeon.add("SantaFe - 2021");
        Subcampeon.add("America De Cali - 2020");

        System.out.println(); // Agrega una línea en blanco
        
        // Recorre la lista de subcampeones y muestra su posición y nombre
        for (int i = 0; i < Subcampeon.size(); i++) {
            int posicion = i + 1; // Sumar 1 para que las posiciones comiencen desde 1
            String nombre = Subcampeon.get(i);
            System.out.println("Subcampeón " + posicion + ": " + nombre);
        }
    }
}

