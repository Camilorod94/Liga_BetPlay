/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package betplayligafemenina_grafico.Modelo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaInformacionAnio extends JFrame {

    public VentanaInformacionAnio(String tituloVentana, String informacionAnio) {
        super(tituloVentana);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 470);
        setLocationRelativeTo(null);

        // Crear un panel izquierdo en blanco
        JPanel panelIzquierdo = new JPanel();

        // Establecer el tamaño del panel izquierdo
        panelIzquierdo.setPreferredSize(new Dimension(150, getHeight()));

        // Crear un JPanel para la información con fondo blanco
        JPanel panelInformacion = new JPanel(new BorderLayout());

        // Crear un JTextArea para mostrar la información del año con fondo transparente
        JTextArea textAreaInformacion = new JTextArea(informacionAnio);
        textAreaInformacion.setEditable(false);
        textAreaInformacion.setFont(new Font("Arial", Font.PLAIN, 16));

        // Crear paneles en blanco arriba y debajo del texto
        JPanel panelArriba = new JPanel();
        JPanel panelAbajo = new JPanel();

        // Configurar el diseño de la ventana principal con un BorderLayout
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // Agregar el panel izquierdo en el lado izquierdo de la ventana
        container.add(panelIzquierdo, BorderLayout.WEST);

        // Agregar el panel de arriba, el JPanel de información en el centro y el panel de abajo
        container.add(panelArriba, BorderLayout.NORTH);
        container.add(panelInformacion, BorderLayout.CENTER);
        container.add(panelAbajo, BorderLayout.SOUTH);

        // Agregar el JTextArea al panel de información
        panelInformacion.add(textAreaInformacion, BorderLayout.CENTER);

        // Crear un panel para los botones "Volver" y "Salir"
        JPanel panelBotones = new JPanel();
        
        // Crear un botón "Volver" para cerrar esta ventana y volver a la ventana anterior
        JButton botonAtras = new JButton("Volver");
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        // Crear un botón "Salir" para cerrar toda la aplicación
        JButton botonSalir = new JButton("Salir");
        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Agregar los botones "Volver" y "Salir" al panel de botones
        panelBotones.add(botonAtras);
        panelBotones.add(botonSalir);

        // Agregar el panel de botones en la parte inferior
        container.add(panelBotones, BorderLayout.SOUTH);
    }
}

