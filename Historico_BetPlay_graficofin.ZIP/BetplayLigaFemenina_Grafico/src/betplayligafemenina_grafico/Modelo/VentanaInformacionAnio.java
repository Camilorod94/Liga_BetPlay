/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico.Modelo;


//Se importan las bibliotecas necesarias, para la interfaz gráfica. 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaInformacionAnio extends JFrame {

    // Constructor de la clase que recibe el título de la ventana y la información del año
    public VentanaInformacionAnio(String tituloVentana, String informacionAnio) {
        super(tituloVentana); // Llama al constructor con el título proporcionado
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Configura el cierre de la ventana al cerrar esta ventana (sin salir de la aplicación), por defecto con el de minimizar y ampliar
        setSize(600, 400); // Establece el tamaño de la ventana a 600x400 píxeles
        setLocationRelativeTo(null); // Centra la ventana en la pantalla

        // Crea un área de texto editable que muestra la información del año
        JTextArea textoInformacion = new JTextArea(informacionAnio);
        textoInformacion.setEditable(false); // Desactiva la edición del texto
        JScrollPane scrollPane = new JScrollPane(textoInformacion); // Agrega un panel de desplazamiento si es necesario, al ser pocos campos no se usa.

        // Crea un botón "Volver" para cerrar esta ventana y volver a la ventana anterior
        JButton botonAtras = new JButton("Volver");
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cierra la ventana actual
            }
        });

        // Crea un botón "Salir" para cerrar toda la aplicación
        JButton botonSalir = new JButton("Salir");
        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Sale de la aplicación
            }
        });

        // Crea un panel para colocar los botones "Volver" y "Salir" uno al lado del otro
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(1, 2)); // Usar un GridLayout para los botones
        panelBotones.add(botonAtras); // Agrega el botón "Volver"
        panelBotones.add(botonSalir); // Agrega el botón "Salir"

        // Configura el diseño de la ventana principal con un BorderLayout
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // Agrega el área de texto en el centro y el panel de botones en la parte inferior
        container.add(scrollPane, BorderLayout.CENTER);
        container.add(panelBotones, BorderLayout.SOUTH);
    }
}






