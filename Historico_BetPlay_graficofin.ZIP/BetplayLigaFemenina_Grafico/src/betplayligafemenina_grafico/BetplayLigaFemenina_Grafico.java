/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package betplayligafemenina_grafico;



import javax.swing.*;


public class BetplayLigaFemenina_Grafico {

    public static void main(String[] args) {
        // Crear una ventana de inicio de sesión
        SwingUtilities.invokeLater(() -> {
            VentanaInicioSesion ventanaInicioSesion = new VentanaInicioSesion();
            ventanaInicioSesion.setVisible(true);
        });
    }
}
