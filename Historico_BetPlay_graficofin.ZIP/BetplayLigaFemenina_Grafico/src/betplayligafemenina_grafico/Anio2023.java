/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico;

public class Anio2023 extends Anio {
    public Anio2023() {
        super(
            2023,
            new Equipo("Santa Fe"),
            new Equipo("América de Cali"),
            new Final(
                new Equipo("Santa Fe"),
                new Equipo("América de Cali"),
                2, 0,
                "Estadio El Campín, Bogotá",
                "Santa Fe"
            ),
            new Final(
                new Equipo("América de Cali"),
                new Equipo("Santa Fe"),
                0, 0,
                "Estadio Pascual Guerrero, Cali",
                "América de Cali"
            ),
            new Jugadora("Catalina Usme", 11)
        );
    }

    @Override
    public String obtenerInfoAnio() {
        return "Año 2023:\n" +
            "Campeón: " + getEquipoCampeon().getNombre() + "\n" +
            "Subcampeón: " + getEquipoSubcampeon().getNombre() + "\n" +
            "Goleadora: " + getGoleadora().getNombre() + " (" + getGoleadora().getGoles() + " goles)\n" +
            "Detalles del partido ida:\n" +
            getFinalPartidoIda().obtenerInfo() + "\n" +
            "Detalles del partido vuelta:\n" +
            getFinalPartidoVuelta().obtenerInfo();
    }
}
