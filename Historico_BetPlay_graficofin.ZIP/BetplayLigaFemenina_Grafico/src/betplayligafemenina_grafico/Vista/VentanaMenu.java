/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package betplayligafemenina_grafico.Vista;

import betplayligafemenina_grafico.controlador.Anio;
import betplayligafemenina_grafico.controlador.Anio2020;
import betplayligafemenina_grafico.controlador.Anio2021;
import betplayligafemenina_grafico.controlador.Anio2022;
import betplayligafemenina_grafico.controlador.Anio2023;
import betplayligafemenina_grafico.Modelo.VentanaInformacionAnio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaMenu extends JFrame {

    public VentanaMenu() {
        // Configuración de la ventana principal
        setTitle("Histórico HISTOBET-FEM"); // Título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cerrar la aplicación al cerrar la ventana
        setSize(600, 500); // Tamaño de la ventana
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setResizable(false); // Evitar que la ventana sea redimensionable

        // Establecer el color de fondo de la ventana
        getContentPane().setBackground(new Color(28, 190, 243));

        // Contenedor para el título
        JPanel panelTitulo = new JPanel();
        panelTitulo.setBackground(new Color(28, 190, 243));

        // Contenedor para el mensaje
        JPanel panelMensaje = new JPanel();
        panelMensaje.setBackground(new Color(28, 190, 243));

        // Contenedor para los botones
        JPanel panelBotones = new JPanel(new GridBagLayout());
        panelBotones.setBackground(new Color(28, 190, 243));

        // Crear botones
        JButton[] botones = new JButton[4];
        for (int i = 0; i < 4; i++) {
            botones[i] = crearBoton("Año " + (2020 + i));
            // Establecer el tamaño preferido de los botones
            botones[i].setPreferredSize(new Dimension(200, 40));
        }

        // Botón de créditos
        JButton botonCreditos = crearBoton("Créditos");
        botonCreditos.setBackground(new Color(198, 148, 3)); // Cambiamos el color de fondo del botón Créditos
        // Establecer el tamaño  del botón de créditos
        botonCreditos.setPreferredSize(new Dimension(200, 40));

        // Botón de salir
        JButton botonSalir = crearBoton("Salir");
        botonSalir.setBackground(new Color(192, 192, 192)); // Color gris plata
        botonSalir.setForeground(Color.RED); // Cambiar el color del texto a rojo
        // Establecer el tamaño  del botón de salir
        botonSalir.setPreferredSize(new Dimension(200, 40));

        // Agregar acciones a los botones de año
        for (int i = 0; i < 4; i++) {
            final int anio = 2020 + i;
            botones[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    mostrarInformacionAnio(anio);
                }
            });
        }

        // Agregar acción al botón de créditos
        botonCreditos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarCreditos();
            }
        });

        // Agregar acción al botón de salir
        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Crear etiquetas de bienvenida y mensaje
        JLabel titulo = new JLabel("Bienvenido a HISTOBET-FEM");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setForeground(Color.BLUE);

        JLabel mensaje = new JLabel("Elija el año del cual desea saber los detalles de la final");
        mensaje.setFont(new Font("Arial", Font.BOLD, 14));
        mensaje.setHorizontalAlignment(SwingConstants.CENTER);
        mensaje.setForeground(Color.BLACK);
        mensaje.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0)); // Agrega espacio alrededor del mensaje

        // Configurar las restricciones para centrar los botones
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 0, 10, 0); // Espacio entre los botones

        // Agregar los botones al panel de botones
        for (int i = 0; i < 4; i++) {
            panelBotones.add(botones[i], gbc);
            gbc.gridy++; // Avanzar a la siguiente fila
        }
        panelBotones.add(botonCreditos, gbc);
        gbc.gridy++;
        panelBotones.add(botonSalir, gbc);

        // Agregar etiquetas y paneles de botones a los contenedores
        panelTitulo.add(titulo);
        panelMensaje.add(mensaje);

        // Agregar los contenedores al contenedor principal
        Container container = getContentPane();
        container.setLayout(new BorderLayout());
        container.add(panelTitulo, BorderLayout.NORTH);
        container.add(panelMensaje, BorderLayout.CENTER);
        container.add(panelBotones, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Método para crear botones con un estilo común
    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 16)); // Aumentamos el tamaño de la fuente

        // Establecer el fondo del botón
        boton.setBackground(new Color(28, 147, 250));
        boton.setForeground(Color.WHITE); // Cambiamos el color del texto a blanco
        boton.setFocusPainted(false); // Quitamos el efecto de enfoque

        return boton;
    }

    // Método para mostrar información de un año específico
    private void mostrarInformacionAnio(int anio) {
        Anio anioSeleccionado = null;
        switch (anio) {
            case 2020:
                anioSeleccionado = new Anio2020();
                break;
            case 2021:
                anioSeleccionado = new Anio2021();
                break;
            case 2022:
                anioSeleccionado = new Anio2022();
                break;
            case 2023:
                anioSeleccionado = new Anio2023();
                break;
        }
        if (anioSeleccionado != null) {
            mostrarVentanaInformacionAnio(anioSeleccionado);
        }
    }

    // Método para mostrar la ventana de información de un año
 private void mostrarVentanaInformacionAnio(Anio anio) {
    VentanaInformacionAnio ventanaInformacionAnio = new VentanaInformacionAnio("Información del Año", anio.obtenerInfoAnio());
    ventanaInformacionAnio.setVisible(true);
}


    // Método para mostrar los créditos
    private void mostrarCreditos() {
        JOptionPane.showMessageDialog(this, "Créditos:\nCristian De Los Rios\ncristian.de.los.rios@pi.edu.co");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaMenu();
            }
        });
    }
}

