/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico.Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaInicioSesion extends JFrame {

    // Constructor de la clase
    public VentanaInicioSesion() {
        // Configuración de la ventana principal
        setTitle("***HISTOBET-FEM***"); // Título de la ventana
        setSize(400, 300); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cerrar la aplicación al cerrar la ventana
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setResizable(false); // Evitar que la ventana sea redimensionable

        // Creación de un panel para organizar los componentes
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout()); // Utilizar un diseño de cuadrícula para organizar los componentes
        panel.setBackground(new Color(28, 190, 243)); // Establecer el color de fondo del panel

        // Configuración de restricciones para el diseño de cuadrícula
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espaciado interno entre los componentes

        // Etiqueta que muestra un mensaje informativo
        JLabel labelMensaje = new JLabel("  Inicia sesión para acceder al histórico BetPlay Femenino");
        labelMensaje.setHorizontalAlignment(JLabel.CENTER); // Alinear el texto al centro
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(labelMensaje, gbc);

        // Etiqueta y campo de texto para ingresar el nombre de usuario
        JLabel labelUsuario = new JLabel("Usuario:");
        JTextField campoUsuario = new JTextField();
        campoUsuario.setPreferredSize(new Dimension(250, 30)); // Establecer el tamaño del campo de texto

        // Etiqueta y campo de contraseña
        JLabel labelContrasena = new JLabel("Contraseña:");
        JPasswordField campoContrasena = new JPasswordField();
        campoContrasena.setPreferredSize(new Dimension(250, 30)); // Establecer el tamaño del campo de contraseña

        // Botón para iniciar sesión
        JButton botonIniciarSesion = new JButton("Iniciar Sesión");

        // Botón para mostrar datos de acceso
        JButton botonDatosAcceso = new JButton("Datos de Acceso");
        botonDatosAcceso.setBackground(new Color(28, 147, 250)); // Cambiar el color del botón a verde

        // Botón para salir de la aplicación
        JButton botonSalir = new JButton("Salir");

        // Configuración de las posiciones de los componentes en la cuadrícula
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(labelUsuario, gbc);

        gbc.gridy = 2;
        panel.add(labelContrasena, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(campoUsuario, gbc);

        gbc.gridy = 2;
        panel.add(campoContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(botonIniciarSesion, gbc);

        gbc.gridy = 4;
        gbc.insets = new Insets(5, 10, 5, 10); // Espacio entre el botón "Datos de Acceso" y "Salir"
        panel.add(botonDatosAcceso, gbc);

        gbc.anchor = GridBagConstraints.SOUTHEAST; // Alinear el botón "Salir" en la esquina inferior derecha
        gbc.gridy = 5;
        panel.add(botonSalir, gbc);

        // Acción del botón "Iniciar Sesión"
        botonIniciarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el usuario y la contraseña ingresados
                String usuario = campoUsuario.getText();
                char[] contrasena = campoContrasena.getPassword();
                String contrasenaStr = new String(contrasena);

                // Verificar si el usuario y la contraseña son correctos
                if (usuario.equals("1") && contrasenaStr.equals("2")) {
                    dispose(); // Cerrar la ventana de inicio de sesión
                    VentanaMenu ventanaMenu = new VentanaMenu(); // Crear una ventana de menú
                    ventanaMenu.setVisible(true); // Mostrar la ventana de menú
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error de inicio de sesión", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Acción del botón "Datos de Acceso"
        botonDatosAcceso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar un mensaje con los datos de acceso
                JOptionPane.showMessageDialog(null, "El usuario es: ciclo3\nLa contraseña es: proyecto", "Datos de Acceso", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Acción del botón "Salir"
        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Cerrar la aplicación
            }
        });

        add(panel); // Agregar el panel a la ventana principal
    }

    // Método principal para ejecutar la aplicación
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaInicioSesion(); // Crear y mostrar la ventana de inicio de sesión
            }
        });
    }
}
