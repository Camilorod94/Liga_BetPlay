/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico;

// Clase que representa los detalles de un partido final en un año específico
public class Final {
    private Equipo equipoLocal;
    private Equipo equipoVisitante;
    private int golesEquipoLocal;
    private int golesEquipoVisitante;
    private String estadio;
    private String ganador;

    // Constructor que recibe los detalles del partido final
    public Final(Equipo equipoLocal, Equipo equipoVisitante, int golesEquipoLocal, int golesEquipoVisitante, String estadio, String ganador) {
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.golesEquipoLocal = golesEquipoLocal;
        this.golesEquipoVisitante = golesEquipoVisitante;
        this.estadio = estadio;
        this.ganador = ganador;
    }

    // Métodos para obtener los detalles del partido final
    public Equipo getEquipoLocal() {
        return equipoLocal;
    }

    public Equipo getEquipoVisitante() {
        return equipoVisitante;
    }

    public int getGolesEquipoLocal() {
        return golesEquipoLocal;
    }

    public int getGolesEquipoVisitante() {
        return golesEquipoVisitante;
    }

    public String getEstadio() {
        return estadio;
    }

    public String getGanador() {
        return ganador;
    }

    // Método para obtener una cadena de información detallada sobre el partido final
    public String obtenerInfo() {
        return "Equipo Local: " + equipoLocal.getNombre() + "\n" +
               "Equipo Visitante: " + equipoVisitante.getNombre() + "\n" +
               "Goles Equipo Local: " + golesEquipoLocal + "\n" +
               "Goles Equipo Visitante: " + golesEquipoVisitante + "\n" +
               "Estadio: " + estadio + "\n" +
               "Ganador: " + ganador + "\n";
    }
}

