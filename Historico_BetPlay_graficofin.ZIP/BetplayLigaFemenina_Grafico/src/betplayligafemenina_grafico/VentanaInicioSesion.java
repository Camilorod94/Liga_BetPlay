/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaInicioSesion extends JFrame {

    private JLabel labelUsuario, labelContrasena, labelMensaje;
    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JButton botonIniciarSesion;
    private JButton botonSalir;

    public VentanaInicioSesion() {
        setTitle("Histórico Liga BetPlay Femenina");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 5, 5, 5); // Aumentado el valor del margen superior

        // Agregar el título centrado en la parte superior
        labelMensaje = new JLabel("  Inicia sesión para acceder a historico BetPlay Femenino");
        labelMensaje.setHorizontalAlignment(JLabel.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(labelMensaje, gbc);

        labelUsuario = new JLabel("Usuario");
        campoUsuario = new JTextField("Ejemplo123");
        labelContrasena = new JLabel("Contraseña:");
        campoContrasena = new JPasswordField("proyecto");
        botonIniciarSesion = new JButton("Acceder");
        botonSalir = new JButton("Salir");

        gbc.gridwidth = 1;

        gbc.gridy = 1;
        panel.add(labelUsuario, gbc);
        gbc.gridx = 1;
        panel.add(campoUsuario, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(labelContrasena, gbc);
        gbc.gridx = 1;
        panel.add(campoContrasena, gbc);

        gbc.gridy = 3;
        gbc.gridx = 0;
        panel.add(botonSalir, gbc);
        gbc.gridx = 1;
        panel.add(botonIniciarSesion, gbc);
        

        botonIniciarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                char[] contrasena = campoContrasena.getPassword();
                String contrasenaStr = new String(contrasena);

                if (usuario.equals("ciclo3") && contrasenaStr.equals("proyecto")) {
                    dispose(); // Cierra la ventana de inicio de sesión
                    VentanaMenu ventanaMenu = new VentanaMenu();
                    ventanaMenu.setVisible(true); // Abre la ventana del menú
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error de inicio de sesión", JOptionPane.ERROR_MESSAGE);// Genera mensaje emergente de error
                }
            }
        });

        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Salir de la aplicación al hacer clic en "Salir"
            }
        });

        add(panel);
    }
}
