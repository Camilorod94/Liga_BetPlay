/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico.controlador;

// Clase que representa un equipo de fútbol
public class Equipo {
    private String nombre;

    // Constructor que recibe el nombre del equipo
    public Equipo(String nombre) {
        this.nombre = nombre;
    }

    // Método para obtener el nombre del equipo
    public String getNombre() {
        return nombre;
    }
}
