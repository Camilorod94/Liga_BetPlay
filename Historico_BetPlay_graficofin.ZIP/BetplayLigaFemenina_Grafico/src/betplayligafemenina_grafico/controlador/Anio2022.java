/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico.controlador;



public class Anio2022 extends Anio {
    public Anio2022() {
        super(
            2022,
            new Equipo("América de Cali"),
            new Equipo("Deportivo Cali"),
            new Final(
                new Equipo("Deportivo Cali"),
                new Equipo("América de Cali"),
                2, 1,
                "Estadio Deportivo Cali, Palmira",
                "Deportivo Cali"
            ),
            new Final(
                new Equipo("América de Cali"),
                new Equipo("Deportivo Cali"),
                3, 1,
                "Estadio Pascual Guerrero, Cali",
                "América de Cali"
            ),
            new Jugadora("Catalina Usme", 15)
        );
    }

    @Override
    public String obtenerInfoAnio() {
        return "Año 2022:\n" +
            "Campeón: " + getEquipoCampeon().getNombre() + "\n" +
            "Subcampeón: " + getEquipoSubcampeon().getNombre() + "\n" +
            "Goleadora: " + getGoleadora().getNombre() + " (" + getGoleadora().getGoles() + " goles)\n" +
            "Detalles del partido ida:\n" +
            getFinalPartidoIda().obtenerInfo() + "\n" +
            "Detalles del partido vuelta:\n" +
            getFinalPartidoVuelta().obtenerInfo();
    }
}

