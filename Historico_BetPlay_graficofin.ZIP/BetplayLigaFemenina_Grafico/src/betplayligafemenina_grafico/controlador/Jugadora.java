/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico.controlador;

// Clase que representa una jugadora y su cantidad de goles en un año específico
public class Jugadora {
    private String nombre;
    private int goles;

    // Constructor que recibe el nombre de la jugadora y la cantidad de goles
    public Jugadora(String nombre, int goles) {
        this.nombre = nombre;
        this.goles = goles;
    }

    // Método para obtener el nombre de la jugadora
    public String getNombre() {
        return nombre;
    }

    // Método para obtener la cantidad de goles que ha marcado la jugadora
    public int getGoles() {
        return goles;
    }
}
