/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico;



public class Anio2021 extends Anio {
    public Anio2021() {
        super(
            2021,
            new Equipo("Deportivo Cali"),
            new Equipo("Santa Fe"),
            new Final(
                new Equipo("Santa Fe"),
                new Equipo("Deportivo Cali"),
                1, 4,
                "Estadio El Campín, Bogotá",
                "Santa Fe"
            ),
            new Final(
                new Equipo("Deportivo Cali"),
                new Equipo("Santa Fe"),
                2, 2,
                "Estadio Deportivo Cali, Palmira",
                "Deportivo Cali"
            ),
            new Jugadora("Catalina Usme", 12)
        );
    }

    @Override
    public String obtenerInfoAnio() {
        return "Año 2021:\n" +
            "Campeón: " + getEquipoCampeon().getNombre() + "\n" +
            "Subcampeón: " + getEquipoSubcampeon().getNombre() + "\n" +
            "Goleadora: " + getGoleadora().getNombre() + " (" + getGoleadora().getGoles() + " goles)\n" +
            "Detalles del partido ida:\n" +
            getFinalPartidoIda().obtenerInfo() + "\n" +
            "Detalles del partido vuelta:\n" +
            getFinalPartidoVuelta().obtenerInfo();
    }
}
