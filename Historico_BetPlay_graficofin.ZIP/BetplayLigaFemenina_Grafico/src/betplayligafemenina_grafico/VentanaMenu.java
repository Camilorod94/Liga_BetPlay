/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_grafico;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaMenu extends JFrame {

    public VentanaMenu() {
        setTitle("Histórico BetPlay Femenino"); // Título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400); // Tamaño de la ventana
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS)); // Usar BoxLayout vertical
        panelBotones.setAlignmentX(Component.CENTER_ALIGNMENT); // Centrar los componentes horizontalmente

        // Agregar el nuevo título dentro del cuerpo de la ventana
        
        JLabel titulo = new JLabel("Bienvenido al Histórico BetPlay Femenino");
        titulo.setFont(new Font("Arial", Font.BOLD, 18)); // Establecer el tipo de fuente y tamaño del título
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT); // Centrar el título horizontalmente
        titulo.setForeground(Color.BLUE); // Cambiar el color del texto
        
        
        
        

        // Agregar el mensaje "Elija el año del cual desea saber los detalles de la final"
        JLabel mensaje = new JLabel("Elija el año del cual desea saber los detalles de la final");
        mensaje.setAlignmentX(Component.CENTER_ALIGNMENT); // Centrar el mensaje horizontalmente
        mensaje.setFont(new Font("Arial", Font.BOLD, 14)); // Establecer el tipo de fuente y tamaño del mensaje
        mensaje.setForeground(Color.black); // Color del texto

        // Crear botones
        JButton botonAnio2020 = new JButton("Año 2020");
        JButton botonAnio2021 = new JButton("Año 2021");
        JButton botonAnio2022 = new JButton("Año 2022");
        JButton botonAnio2023 = new JButton("Año 2023");
        JButton botonSalir = new JButton("Salir");

        // Ajustar el tamaño de los botones en la ventana
        Dimension buttonSize = new Dimension(300, 100);
        botonAnio2020.setPreferredSize(buttonSize);
        botonAnio2021.setPreferredSize(buttonSize);
        botonAnio2022.setPreferredSize(buttonSize);
        botonAnio2023.setPreferredSize(buttonSize);
        botonSalir.setPreferredSize(buttonSize);

        botonAnio2020.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Anio2020 anio2020 = new Anio2020();
                mostrarVentanaInformacionAnio(anio2020);
            }
        });

        botonAnio2021.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Anio2021 anio2021 = new Anio2021();
                mostrarVentanaInformacionAnio(anio2021);
            }
        });

        botonAnio2022.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Anio2022 anio2022 = new Anio2022();
                mostrarVentanaInformacionAnio(anio2022);
            }
        });

        botonAnio2023.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Anio2023 anio2023 = new Anio2023();
                mostrarVentanaInformacionAnio(anio2023);
            }
        });

        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Agregar el mensaje y botones al panel de botones
        panelBotones.add(titulo); // Agregar el título al panel de botones
        panelBotones.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio vertical antes del mensaje
        panelBotones.add(mensaje);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio vertical entre el mensaje y los botones
        panelBotones.add(botonAnio2020);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio vertical entre botones
        panelBotones.add(botonAnio2021);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10)));
        panelBotones.add(botonAnio2022);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 10)));
        panelBotones.add(botonAnio2023);
        panelBotones.add(Box.createRigidArea(new Dimension(0, 25))); // Espacio vertical entre los botones y el borde inferior
        panelBotones.add(botonSalir);
        

        Container container = getContentPane();
        container.setLayout(new BorderLayout());
        container.add(panelBotones, BorderLayout.CENTER); // Centrar el panel de botones en la ventana

        setVisible(true);
    }

    private void mostrarVentanaInformacionAnio(Anio anio) {
        VentanaInformacionAnio ventanaInformacionAnio = new VentanaInformacionAnio("Información del Año", anio.obtenerInfoAnio());
        ventanaInformacionAnio.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaMenu();
            }
        });
    }
}
