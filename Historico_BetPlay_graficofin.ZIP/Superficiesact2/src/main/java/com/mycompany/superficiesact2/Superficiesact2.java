/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.superficiesact2;

import java.util.Scanner;

/**
 *
 * @author Cristrian De Los Rios
 */
public class Superficiesact2 {

    public static void main(String[] args) {
        int x; // se da valor a X como entero
        Scanner op=new Scanner(System.in); //Se habilita Scanner OP para el Swich
        Scanner sup=new Scanner(System.in); // Scanner para Base y Altura
        do{       
        System.out.println( " 1.Triangulo\n 2.Cuadrado\n 3.Rectangulo\n 4.Imprimir\n 5.Ciclo While\n 6.Salir"); // Se imprimen las "Opciones" del menú.
        System.out.println("Dígite opción");
        x=op.nextInt(); //Para que el usuario ingrese la opción.
        switch(x) { // Se abre un Switch para dar diferentes opciones. 
            
          
            
            case 1 -> {
                double b, h, area, perimetro, L1,L2,L3; // Se asignan valores como 
                System.out.println("Ha elegido el triangulo"); // Se imprime en pantalla lo de comillas.
                System.out.println("Ingrese el valor del lado 1"); // Se imprime en pantalla lo de entre comillas, igual para cada Sout.
                L1=sup.nextDouble(); //L1 se asigna como "lado", para que el usuario ingrese el valor de L1 por teclado. 
                System.out.println("Ingrese el valor del lado 2");
                L2=sup.nextDouble(); //L2 se asigna como "lado", para que el usuario ingrese el valor de L2 por teclado.
                System.out.println("Ingrese el valor del lado 3");
                L3=sup.nextDouble();
                System.out.println("Ingrese la base del triángulo");
                b=sup.nextDouble(); //b se asigna como "sup", para que el usuario ingrese el valor de a "base" por teclado.
                System.out.println("Ingrese la altura del triángulo");
                h=sup.nextDouble(); //h se asigna como "sup", para que el usuario ingrese el valor de a "altura" por teclado.               
                perimetro = L1+L2+L3; // Se crea formula para calcular el perimetro, que es la suma de todos los lados ingresados antes
                System.out.println("El perimetro del triángulo es: "+perimetro); // Se imprime en pantalla el valor del perimetro
                area=(b*h)/2;// Se crea formula para calcular el área
                System.out.println("El área del triángulo es: "+area); // Se imprime el área en pantalla
            }

            case 2 ->  {
                double lados, i;
                System.out.println("Para calcular el área del Cuadrado dígite 1 o 2 para calcular el Perímetro");
                i=sup.nextDouble();
                System.out.println("Ingrese el valor del lado");
                lados=sup.nextDouble();
                cuadrado(i,lados);
            }

            case 3 -> {
                double bajo, i, alto;
                System.out.println("Para calcular el área del rectangulo dígite 1 o 2 para calcular el Perímetro");
                i=sup.nextDouble();
                System.out.println("Ingrese el valor de la base");
                bajo=sup.nextDouble();
                System.out.println("Ingrese el valor de la altura");
                alto=sup.nextDouble();
                rectangulo(i,bajo,alto);
            }
            
            
            case 4 -> {
                double n;
                 System.out.print("Ingrese la cantidad de números a imprimir: ");
                n=sup.nextDouble();

                System.out.println("Sus números son:");

                for (int i = 1; i <= n; i++) 
                {
                 System.out.println(i);
                }   
            }
            
            case 5 -> {
                System.out.println("Ingrese un número mayor a 30 y podrá salir de este ciclo");
                
                double num =sup.nextDouble();
                while(num <= 30)
                {
                    System.out.println("Continua en nuestro ciclo, ingrese otro número.");
                    num=sup.nextDouble();
                }
                
            }  
            
            case 6 -> {
                System.out.println("Gracias por usar el sistema ¡Hasta pronto!");
               
            }
                default -> System.out.println("Por favor ingresar únicamente números de la lista.");
        }
        }while(x!=6);
        
 
    }
    public static void cuadrado(double i,double la){
        double area,perimetro;
        if (i==1)
        {
            area=la*la;
            System.out.println("El área del Cuadrado es: "+area);
        }
        else
        {    
            perimetro=la*4;
            System.out.println("El perímetro del Cuadrado es: "+perimetro);
            
        }
        
    }
    
     public static void rectangulo(double i,double la, double l2){
        double area,perimetro;
        if (i==1)
        {
            area=la*l2;
            System.out.println("El área del rectángulo es: "+area);
        }
        else
        {    
            perimetro=la+l2+la+l2;
            System.out.println("El perímetro del rectángulo es: "+perimetro);
            
        }
        
    }
    
    
    
}
