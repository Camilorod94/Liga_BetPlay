/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_lista;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DetallesAnios {
    
    
    
public static void main(String[] args) {
    
    System.out.println("");//Se deja espacio para separar del título
    System.out.println("**Aqui encontrará el detalle de las finales de los últimos años***");
        // Crear una "Lista Genérica Diversa" para los Equipos finalistas
        List<Map<String, Object>> Anios = new ArrayList<>();
        
        System.out.println();//agrega una línea en blanco
        
        // Agregar información de participantes para varios años
        Map<String, Object> Anio2023 = new HashMap<>();
        Anio2023.put("campeon", "SantaFe");
        Anio2023.put("Subcampeon", "AmericaDeCali");
        Anio2023.put("Partido Ida", "SantaFe 2 - 0 AmericaDeCali");
        Anio2023.put("Partido vuelta", "America de Cali 0 - 0 Santa Fe");
        Anio2023.put("Goles", 11);
        Anios.add(Anio2023);

        Map<String, Object> Anio2022 = new HashMap<>();
        Anio2022.put("campeon", "AmericaDeCali ");
        Anio2022.put("Subcampeon", "Deportivo Cali");
        Anio2022.put("Partido Ida", "Deportivo Cali 2 - 1 America de Cali");
        Anio2022.put("Partido vuelta", "America de Cali 3 - 1 Deportivo Cali");
        Anio2022.put("Goles", 15);
        Anios.add(Anio2022);

        Map<String, Object> Anio2021 = new HashMap<>();
        Anio2021.put("campeon", "Deportivo Cali");
        Anio2021.put("Subcampeon", "SantaFe");
        Anio2021.put("Partido Ida", "Santa Fe 1 - 4 Deportivo Cali");
        Anio2021.put("Partido vuelta", "Deportivo Cali 2 - 2 Santa Fe");
        Anio2021.put("Goles", 12);
        Anios.add(Anio2021);
        
        Map<String, Object> Anio2020 = new HashMap<>();
        Anio2020.put("campeon", "SantaFe ");
        Anio2020.put("Subcampeon", "America de Cali");
        Anio2020.put("Partido Ida", "America de Cali 1 - 1 SantaFe");
        Anio2020.put("Partido vuelta", "SantaFe 2 - 0 America de Cali");
        Anio2020.put("Goles", 13);
        Anios.add(Anio2020);
        



          // Mostrar información de un año específico (2023)
        Map<String, Object> Info2023 = Anios.get(0); 
        System.out.println("Informacion del año 2023:");
        System.out.println("Equipo Campeon: " + Info2023.get("campeon"));
        System.out.println("Equipo Subcampeon: " + Info2023.get("Subcampeon"));
        System.out.println("Partido Ida: " + Info2023.get("Partido Ida"));
        System.out.println("Partido Vuelta: " + Info2023.get("Partido vuelta"));
        System.out.println("Total Goles temporada: " + Info2023.get("Goles"));
        
        // Repetir el proceso para otros años
        // ...
        
        System.out.println();
        
        Map<String, Object> info2022 = Anios.get(1); 
        System.out.println("Informacion del año 2022:");
        System.out.println("Equipo Campeon: " + info2022.get("campeon"));
        System.out.println("Equipo Subcampeon: " + info2022.get("Subcampeon"));
        System.out.println("Partido Ida: " + info2022.get("Partido Ida"));
        System.out.println("Partido Vuelta: " + info2022.get("Partido vuelta"));
        System.out.println("Total Goles temporada: " + info2022.get("Goles"));
        
        System.out.println();
        
        Map<String, Object> info2021= Anios.get(2); 
        System.out.println("Informacion del año 2021:");
        System.out.println("Equipo Campeon: " + info2021.get("campeon"));
        System.out.println("Equipo Subcampeon: " + info2021.get("Subcampeon"));
        System.out.println("Partido Ida: " + info2021.get("Partido Ida"));
        System.out.println("Partido Vuelta: " + info2021.get("Partido vuelta"));
        System.out.println("Total Goles temporada: " + info2021.get("Goles"));
        
        System.out.println();
        
        Map<String, Object> info2020= Anios.get(3); 
        System.out.println("Informacion del año 2020:");
        System.out.println("Equipo Campeon: " + info2020.get("campeon"));
        System.out.println("Equipo Subcampeon: " + info2020.get("Subcampeon"));
        System.out.println("Partido Ida: " + info2020.get("Partido Ida"));
        System.out.println("Partido Vuelta: " + info2020.get("Partido vuelta"));
        System.out.println("Total Goles temporada: " + info2020.get("Goles"));
        
        System.out.println();

    }
}
