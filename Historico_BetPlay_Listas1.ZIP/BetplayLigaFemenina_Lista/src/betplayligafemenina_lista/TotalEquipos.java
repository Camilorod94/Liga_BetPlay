/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betplayligafemenina_lista;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta clase muestra una lista de equipos que han participado en la Liga BetPlay Femenina en los últimos 4 años.
 * Los nombres de los equipos se almacenan en una lista y luego se imprimen en la consola.
 * @author Kmilo
 */
public class TotalEquipos {
    public static void main(String[] args) {
        // Crear una lista tipada para almacenar cadenas de caracteres
        List<String> listaTipada = new ArrayList<>();
        
        // Agregar elementos a la lista
        listaTipada.add("America De Cali");
        listaTipada.add("Deportivo Cali");
        listaTipada.add("SantaFe");
        
        
        
        System.out.println();// Agrega una línea en blanco
        
        // Imprimir los elementos de la lista
        System.out.println("Equipos de la Liga BetPlay Femenina que participaron en las finales estos últimos 4 años :\n"); 
        for (String elemento : listaTipada) {
            System.out.println(elemento);
        }
    }
}

