/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package betplayligafemenina_lista;


import java.util.Scanner;
/**
 *
 * @author Kmilo
 */
public class BetplayLigaFemenina_Lista {

 public static void main(String[] args) {
        Scanner scr = new Scanner(System.in); // Creamos un Scanner para obtener entrada del usuario
        int opcion; // Variable para almacenar la opción seleccionada por el usuario
        System.out.println("BIENVENIDO A SU HISTORICO BETPLAYFEM2023\n");

        do {
            // Mostramos el menú al usuario
            System.out.println("\nMenu:");
            System.out.println("1. Subcampeones de los últimos 4 años ");
            System.out.println("2. Total de Equipos que participaron ");
            System.out.println("3. Datos de cada Año");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scr.nextInt(); // Obtenemos la opción elegida por el usuario

            switch (opcion) {
                case 1:
                    // Mostramos datos de la Liga BetPlayFem2023
                    System.out.println("SUBCAMPEONES DE LOS ULTIMOS 4 AÑOS :");
                    SUBCAMPEONES.main(args);
                    break;
                case 2:
                    // Mostramos equipos que clasifican para la final
                    System.out.println("\n\nEQUIPOS QUE HAN JUGADO EN TODAS LAS TEMPORADAS");
                    TotalEquipos.main(args);
                    break;
                case 3:
                    // Mostramos datos sobre el equipo
                    System.out.println("\n\nDATOS DE LOS ULTIMOS 4 AÑOS:");
                    DetallesAnios.main(args);
                    break;
                case 4:
                    // Salimos del programa
                    System.out.println("BYE!");
                    break;
                default:
                    // Si la opción no es válida, mostramos un mensaje de error
                    System.out.println("Opcion no valida. Por favor, seleccione una opcion valida.");
                    break;
            }

        } while (opcion != 5); // Continuamos el bucle mientras la opción no sea 5 (Salir)
    }
}
